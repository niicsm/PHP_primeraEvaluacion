<?php
$pistasTransportes = array (
    "pista1" => array("¡Tiene ruedas!", "¡No tiene ruedas!"),
    "pista2" => array("¡Es un vehiculo a motor!", "¡Va por las vías!", "¡Va por el mar!", "¡Va por el aire!","¡Un método de transporte muy ecológico!" ),
    
);
$pistasColores = array (
    "pista1" => array("¡Es un color primario!", "¡No es una color primario!"),
    "pista2" => array("Es uno de los colores RGB", "¡Es uno de los colores CMYK!", "¡No es ni RGB ni CMYK!", "¡!" ),
);
$pistasFrutas = array (
    "pista1" => array("¡Nace en el suelo!", "¡Nace en los arboles!"),
    "pista2" => array("¡Es un fruto seco!", "¡Puede ser de color amarillo!", "¡Es de color naranja!", "¡Es roja y verde!", "¡Está en la playa!" ),
);
?>